﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

	public Vector3 jump;
	public float jumpForce = 2.0f;

	public float xSpeed = 150f;
	public float zSpeed = 4f;
	public bool isGrounded;
	public bool isRunning;
	Rigidbody rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody> ();
		jump = new Vector3 (0.0f, 2.0f, 0.0f);

		//Cursor.lockState = CursorLockMode.Locked;
	}
	void OnTriggerEnter(Collider collider)
	{
		isGrounded = true;


		if (collider.gameObject.tag == "SlowDown") {
			zSpeed = 1f;
		}
	}

	void OnTriggerExit(Collider collider2){
		isGrounded = false;

		if (collider2.gameObject.tag == "SlowDown") {
			zSpeed = 4f;
		}
	}

	// Update is called once per frame
	void Update () {


		var x = Input.GetAxis ("Horizontal") * Time.deltaTime * xSpeed;
		var z = Input.GetAxis ("Vertical") * Time.deltaTime * zSpeed *(isRunning? 2.0f : 1.0f);
		transform.Rotate (0, x, 0);
		transform.Translate (0, 0, z);

	
		if (Input.GetKeyDown (KeyCode.Space) && isGrounded) {
			rb.AddForce (jump * jumpForce, ForceMode.Impulse);
			isGrounded = false;

		}

			if (Input.GetKey (KeyCode.LeftShift)) {
				isRunning = true;
			}else{
				isRunning =false; 
	

		

		//if (Input.GetKeyDown("escape")) {
			//Cursor.lockState = CursorLockMode.None;

		


}
}



	
}

