﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

	public Vector3 jump;
	public float jumpForce = 2.0f;

	public float xSpeed = 150f;
	public float zSpeed = 4f;



	public bool isGrounded;
	Rigidbody rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody> ();
		jump = new Vector3 (0.0f, 2.0f, 0.0f);

		//Cursor.lockState = CursorLockMode.Locked;
	}
	void OnCollisionStay()
	{
		isGrounded = true;
	}
	// Update is called once per frame
	void Update () {
		var x = Input.GetAxis ("Horizontal") * Time.deltaTime * xSpeed;
		var z = Input.GetAxis ("Vertical") * Time.deltaTime * zSpeed;
		transform.Rotate (0, x, 0);
		transform.Translate (0, 0, z);

	
		if (Input.GetKeyDown (KeyCode.Space) && isGrounded) {
			rb.AddForce (jump * jumpForce, ForceMode.Impulse);
			isGrounded = false;

		


		}
	}
		

		void OnCollisionEnter(Collision collision){
			if (collision.gameObject.tag == "Ladder") {
				zSpeed = 0;

			}
		}

		void OnCollisionExit (Collision collision2){
			if (collision2.gameObject.tag == "Ladder") {
				zSpeed = 4;

			}

		}
	}


		

		//if (Input.GetKeyDown("escape")) {
			//Cursor.lockState = CursorLockMode.None;




	
//}

