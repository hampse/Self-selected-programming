﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpScript : MonoBehaviour {

	public GameObject collect;

	public GameObject collect2;
	// Use this for initialization
	void Start () {

	


	}
	
	// Update is called once per frame
	void Update () {
		RaycastHit hit;


		Ray ray = new Ray (transform.position, Vector3.forward);

		Debug.DrawRay (transform.position, Vector3.forward * 0.8f, Color.black);

		if (Physics.Raycast (ray, out hit, 0.8f)) {


			if (Input.GetKey (KeyCode.X)){
				if (hit.collider.tag == ("Collectable"))
					Destroy (collect);
			

				Debug.Log ("Hit");
			}

			if (Input.GetKey (KeyCode.X)){
				if (hit.collider.tag == ("Collectable"))
					Destroy (collect2);


				Debug.Log ("Hit");
			}


		}
	}
}





	

