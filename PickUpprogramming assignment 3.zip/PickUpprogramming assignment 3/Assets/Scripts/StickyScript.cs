﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StickyScript : MonoBehaviour {

	public float slowDown = -1f;

	Rigidbody rb;


	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody> ();
		
	}
	
	// Update is called once per frame
	void Update () {
		
	
			
		}
		//other.Rigidbody.AddForce (Vector3.forward * slowDown, ForceMode.Acceleration);



	}

