﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LadderScript : MonoBehaviour {

	GameObject playerObject;
	bool climb = false;
	float speed = 10f;
		

		
	// Use this for initialization
	void Start () {
		
	}


	void OnCollisionEnter(Collision collision){
		if (collision.gameObject.tag == "Player") {

			climb = true;
			playerObject = collision.gameObject;

		}

	}
	void OnCollisionExit(Collision collision2){
		if (collision2.gameObject.tag == "Player") {
			climb = false;
			playerObject = null;
		}
	}

		// Update is called once per frame
		void Update () {
		if (climb) {

			if (Input.GetKey(KeyCode.W)) {
				playerObject.transform.Translate (new Vector3 (0, 1, 0) * Time.deltaTime * speed);
			
		}

			
		}

		}



}
